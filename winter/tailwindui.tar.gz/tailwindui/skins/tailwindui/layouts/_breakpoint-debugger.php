
<div class="visible md:invisible bg-pink-500 p-1 fixed top-0 left-0 text-xs font-mono text-white flex items-center justify-center print:hidden">sm</div>
<div class="invisible md:visible bg-orange-500 p-1 fixed top-0 left-0 text-xs font-mono text-white flex items-center justify-center print:hidden">md</div>
<div class="invisible lg:visible bg-green-500 p-1 fixed top-0 left-0 text-xs font-mono text-white flex items-center justify-center print:hidden">lg</div>
<div class="invisible xl:visible bg-blue-500 p-1 fixed top-0 left-0 text-xs font-mono text-white flex items-center justify-center print:hidden">xl</div>
<div class="invisible 2xl:visible bg-purple-500 p-1 fixed top-0 left-0 text-xs font-mono text-white flex items-center justify-center print:hidden">2xl</div>
